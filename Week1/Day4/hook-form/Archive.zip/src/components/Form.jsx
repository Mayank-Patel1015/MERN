import { useState } from "react"

const Form = (props) => {

  const [firstName, setFirstName] = useState("")
  const [lastName, setLastName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")

  const submitHandler = (e) => {
    const personObj = {
      firstName,
      lastName,
      email,
      password,
      confirmPassword
    };
    console.log(personObj)
  };

  return (
    <fieldset>
      <legend>Form.jsx</legend>
      <form onSubmit={submitHandler}>
        <label htmlFor="firstName">firstname:</label>
        <input type="text" id="firstName" onChange={(e) => setFirstName(e.target.value)} /> <br />
        <label htmlFor="lastName">lastname:</label>
        <input type="text" id="lastName" onChange={(e) => setLastName(e.target.value)} /> <br />
        <label htmlFor="email">email:</label>
        <input type="text" id="email" onChange={(e) => setEmail(e.target.value)} /> <br />
        <label htmlFor="password">password:</label>
        <input type="text" id="password" onChange={(e) => setPassword(e.target.value)} /> <br />
        <label htmlFor="confirmPassword">confirm password:</label>
        <input type="text" id="confirmPassword" onChange={(e) => setConfirmPassword(e.target.value)} /> <br />
        <button> submit </button>
      </form>
      <div>
        <p>First Name: {firstName} </p>
        <p>Last Name: {lastName} </p>
        <p>Email: {email} </p>
        <p>Password: {password} </p>
        <p>Confirm Paswword: {confirmPassword} </p>
      </div>
    </fieldset>
  )
}

export default Form