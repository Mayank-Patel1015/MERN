import React from 'react'

const Main = (props) => {
  return (
    <h1>Main</h1>
  )
}

export default Main